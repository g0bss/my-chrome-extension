console.log("Content script da Minha Extensão carregado!");
// Exemplo: muda a cor de fundo de todas as páginas para um tom suave
document.body.style.backgroundColor = '#f0f8ff';